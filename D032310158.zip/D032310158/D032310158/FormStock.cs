﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace D032310158
{
    public partial class FormStock : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\matpa\source\repos\D032310158\D032310158\AdmiralBookstoreDatabase.mdf;Integrated Security=True;Connect Timeout=30";
        public FormStock()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Stock", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                stockDataGridView.DataSource = dt;
            }
        }



        private void stockBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.stockBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bookstoreDataSet);

        }

        private void FormStock_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bookstoreDataSet.Stock' table. You can move, or remove it, as needed.
            this.stockTableAdapter.Fill(this.bookstoreDataSet.Stock);

        }

        private void buttonFormBook_Click(object sender, EventArgs e)
        {
            new FormBook().Show();
            this.Hide();
        }

        private void buttonFormAuthor_Click(object sender, EventArgs e)
        {
            new FormAuthor().Show();
            this.Hide();
        }

       

        private void labelStockID_Click(object sender, EventArgs e)
        {

        }

        private void textBoxStockID_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelAuthorID_Click(object sender, EventArgs e)
        {

        }

        private void textBoxAuthorID_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelISBN13_Click(object sender, EventArgs e)
        {

        }

        private void textBoxISBN13_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelQuantityInStock_Click(object sender, EventArgs e)
        {

        }

        private void textBoxQuantityInStock_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelDateRecorded_Click(object sender, EventArgs e)
        {

        }

        private void textBoxDateRecorded_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string sql = "DELETE FROM Stock WHERE StockID = @id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", textBoxStockID.Text);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            LoadData();
        }

        private void stockDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                textBoxStockID.Text = stockDataGridView.Rows[e.RowIndex].Cells[0].Value?.ToString();
                textBoxAuthorID.Text = stockDataGridView.Rows[e.RowIndex].Cells[1].Value?.ToString();
                textBoxISBN13.Text = stockDataGridView.Rows[e.RowIndex].Cells[2].Value?.ToString();
                textBoxQuantityInStock.Text = stockDataGridView.Rows[e.RowIndex].Cells[3].Value?.ToString();
                textBoxDateRecorded.Text = Convert.ToDateTime(stockDataGridView.Rows[e.RowIndex].Cells[4].Value).ToString("yyyy-MM-dd");
            }
        }
    }
}
