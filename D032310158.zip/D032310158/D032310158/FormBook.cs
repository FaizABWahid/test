﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace D032310158
{
    public partial class FormBook : Form
    {

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\matpa\source\repos\D032310158\D032310158\AdmiralBookstoreDatabase.mdf;Integrated Security=True;Connect Timeout=30";
        public FormBook()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Book", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                bookDataGridView.DataSource = dt;
            }
        }


        private void bookBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.bookBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bookstoreDataSet);

        }

        private void FormBook_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bookstoreDataSet.Book' table. You can move, or remove it, as needed.
            this.bookTableAdapter.Fill(this.bookstoreDataSet.Book);

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {

        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                // Use the correct column name for the publish date
                string sql = "UPDATE Book SET Title=@title, Publisher=@pub, PublisherDate=@date WHERE [ISBN-13]=@isbn";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@isbn", textBoxISBN13.Text);
                cmd.Parameters.AddWithValue("@title", textBoxTitle.Text);
                cmd.Parameters.AddWithValue("@pub", textBoxPublisher.Text);
                cmd.Parameters.AddWithValue("@date", textBoxPublisherDate.Text);

               
                

                conn.Open();
                cmd.ExecuteNonQuery();
            }
            LoadData();
        }

        private void buttonFormAuthor_Click(object sender, EventArgs e)
        {
            new FormAuthor().Show();
            this.Hide();
        }

        private void buttonFormStock_Click(object sender, EventArgs e)
        {
            new FormStock().Show();
            this.Hide();
        }

        private void bookDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                textBoxISBN13.Text = bookDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                textBoxTitle.Text = bookDataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBoxPublisher.Text = bookDataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBoxPublisherDate.Text = Convert.ToDateTime(bookDataGridView.Rows[e.RowIndex].Cells[3].Value).ToString("yyyy-MM-dd");
            }
        }

        private void ISBN13label_Click(object sender, EventArgs e)
        {

        }

        private void textBoxISBN13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxTitle_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelTitle_Click(object sender, EventArgs e)
        {

        }

        private void textBoxPublisher_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelPublisher_Click(object sender, EventArgs e)
        {

        }

        private void textBoxPublisherDate_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelPublisherDate_Click(object sender, EventArgs e)
        {

        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {

        }
    }
}
