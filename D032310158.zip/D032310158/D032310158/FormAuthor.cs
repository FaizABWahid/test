﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace D032310158
{
    public partial class FormAuthor : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\matpa\source\repos\D032310158\D032310158\AdmiralBookstoreDatabase.mdf;Integrated Security=True;Connect Timeout=30";

       
        public FormAuthor()
        {
            InitializeComponent();
            LoadData();
        }


        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Author", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                authorDataGridView.DataSource = dt;
            }
        }



        private void authorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.authorBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bookstoreDataSet);

        }

        private void FormAuthor_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bookstoreDataSet.Author' table. You can move, or remove it, as needed.
            this.authorTableAdapter.Fill(this.bookstoreDataSet.Author);

        }

        private void AuthorIDlabel_Click(object sender, EventArgs e)
        {

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Author (AuthorID, Name, BirthYear) VALUES (@AuthorID, @Name, @BirthYear)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@AuthorID", AuthorIDtextBox.Text);
                    cmd.Parameters.AddWithValue("@Name", NametextBox.Text);
                    cmd.Parameters.AddWithValue("@BirthYear", BirthYeartextBox.Text);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        

        private void buttonDelete_Click(object sender, EventArgs e)
        {

        }

        private void buttonFormBook_Click(object sender, EventArgs e)
        {
            new FormBook().Show();
            this.Hide();
        }

        private void buttonFormStock_Click(object sender, EventArgs e)
        {
            new FormStock().Show();
            this.Hide();
        }

        private void authorDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void AuthorIDtextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Namelabel_Click(object sender, EventArgs e)
        {

        }

        private void NametextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void BirthYearlabel_Click(object sender, EventArgs e)
        {

        }

        private void BirthYeartextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
